import React from 'react'

const table = () => {
  return (
   
    <>
     <div>table</div>
     <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td></td>
            </tr>
        </tbody>
     </table>
     
     </>
  )
}

export default table